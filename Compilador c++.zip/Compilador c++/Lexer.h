#include <iterator>
#include <string>
#include <regex>
#include <map>

using namespace std;
class Lexer{

    public:
        Lexer();
        string Tokenizar(string str);
        ~Lexer();
};
