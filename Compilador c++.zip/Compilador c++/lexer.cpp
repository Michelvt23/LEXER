#include "Lexer.h"

Lexer::Lexer(){
}

string Lexer::Tokenizar(string str){
            // storage for results
            string aux  = " ";
            map<string,string> patterns {
                                     { "si|selse|mientras|para|haz|nular|vacio|clase", "PALABRA RESERVADA"},
                                     { "[0-9]+" ,   "NUMERO" },
                                     { "[a-z]+" ,   "IDENTIFICADOR" },
                                     { "\\*|\\+",  "OPERADOR" }};

            map< size_t, pair<string,string> > matches;

            for ( auto pat = patterns.begin(); pat != patterns.end(); ++pat )
            {
                regex r(pat->first);
                auto words_begin = sregex_iterator( str.begin(), str.end(), r );
                auto words_end   = sregex_iterator();

                for ( auto it = words_begin; it != words_end; ++it )
                    matches[ it->position() ] = make_pair( it->str(), pat->second );
            }

            for ( auto match = matches.begin(); match != matches.end(); ++match )
                aux = aux + match->second.first + " " + match->second.second +"\n";

            return aux;
        }
