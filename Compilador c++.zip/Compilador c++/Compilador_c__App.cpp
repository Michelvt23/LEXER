/***************************************************************
 * Name:      Compilador_c__App.cpp
 * Purpose:   Code for Application Class
 * Author:     ()
 * Created:   2017-11-21
 * Copyright:  ()
 * License:
 **************************************************************/

#include "Compilador_c__App.h"

//(*AppHeaders
#include "Compilador_c__Main.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(Compilador_c__App);

bool Compilador_c__App::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	Compilador_c__Frame* Frame = new Compilador_c__Frame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
