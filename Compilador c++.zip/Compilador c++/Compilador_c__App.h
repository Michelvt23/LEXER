/***************************************************************
 * Name:      Compilador_c__App.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2017-11-21
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef COMPILADOR_C__APP_H
#define COMPILADOR_C__APP_H

#include <wx/app.h>

class Compilador_c__App : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // COMPILADOR_C__APP_H
