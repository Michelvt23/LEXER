/***************************************************************
 * Name:      Compilador_c__Main.h
 * Purpose:   Defines Application Frame
 * Author:     ()
 * Created:   2017-11-21
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef COMPILADOR_C__MAIN_H
#define COMPILADOR_C__MAIN_H

//(*Headers(Compilador_c__Frame)
#include <wx/menu.h>
#include <wx/textctrl.h>
#include <wx/frame.h>
#include <wx/statusbr.h>
//*)

class Compilador_c__Frame: public wxFrame
{
    public:

        Compilador_c__Frame(wxWindow* parent,wxWindowID id = -1);
        virtual ~Compilador_c__Frame();

    private:

        //(*Handlers(Compilador_c__Frame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnTextCtrl1Text(wxCommandEvent& event);
        void OnCompilar(wxCommandEvent& event);
        //*)

        //(*Identifiers(Compilador_c__Frame)
        static const long ID_TEXTCTRL1;
        static const long idCompliar;
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(Compilador_c__Frame)
        wxMenuItem* MenuItem3;
        wxStatusBar* StatusBar1;
        wxTextCtrl* TextCtrl1;
        //*)
         wxTextCtrl* getwxTextCtrl();
        DECLARE_EVENT_TABLE()
};

#endif // COMPILADOR_C__MAIN_H
