/***************************************************************
 * Name:      Compilador_c__Main.cpp
 * Purpose:   Code for Application Frame
 * Author:     ()
 * Created:   2017-11-21
 * Copyright:  ()
 * License:
 **************************************************************/

#include "Compilador_c__Main.h"
#include "Lexer.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(Compilador_c__Frame)
#include <wx/font.h>
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(Compilador_c__Frame)
const long Compilador_c__Frame::ID_TEXTCTRL1 = wxNewId();
const long Compilador_c__Frame::idCompliar = wxNewId();
const long Compilador_c__Frame::idMenuQuit = wxNewId();
const long Compilador_c__Frame::idMenuAbout = wxNewId();
const long Compilador_c__Frame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(Compilador_c__Frame,wxFrame)
    //(*EventTable(Compilador_c__Frame)
    //*)
END_EVENT_TABLE()

Compilador_c__Frame::Compilador_c__Frame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(Compilador_c__Frame)
    wxMenuItem* MenuItem2;
    wxMenuItem* MenuItem1;
    wxMenu* Menu1;
    wxMenuBar* MenuBar1;
    wxMenu* Menu2;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    TextCtrl1 = new wxTextCtrl(this, ID_TEXTCTRL1, _("/*Inserte un texto ac�*/"), wxPoint(8,16), wxDefaultSize, wxTE_MULTILINE|wxTE_RICH, wxDefaultValidator, _T("ID_TEXTCTRL1"));
    wxFont TextCtrl1Font(wxDEFAULT,wxFONTFAMILY_DECORATIVE,wxFONTSTYLE_NORMAL,wxFONTWEIGHT_LIGHT,false,_T("Bradley Hand ITC"),wxFONTENCODING_DEFAULT);
    TextCtrl1->SetFont(TextCtrl1Font);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem3 = new wxMenuItem(Menu1, idCompliar, _("Compilar\tF10"), _("Compila el proyecto"), wxITEM_NORMAL);
    Menu1->Append(MenuItem3);
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Salir\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&Archivo"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Ayuda"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);

    Connect(ID_TEXTCTRL1,wxEVT_COMMAND_TEXT_UPDATED,(wxObjectEventFunction)&Compilador_c__Frame::OnTextCtrl1Text);
    Connect(idCompliar,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&Compilador_c__Frame::OnCompilar);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&Compilador_c__Frame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&Compilador_c__Frame::OnAbout);
    //*)
}

Compilador_c__Frame::~Compilador_c__Frame()
{
    //(*Destroy(Compilador_c__Frame)
    //*)
}

void Compilador_c__Frame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void Compilador_c__Frame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}
size_t r = 0;
int aux = 0;
wxTextCtrl* Compilador_c__Frame::getwxTextCtrl(){
    return TextCtrl1;
}
void Compilador_c__Frame::OnTextCtrl1Text(wxCommandEvent& event)
{
    if ( aux > (int) getwxTextCtrl()->GetValue().size()) aux = 0;

        if(getwxTextCtrl()->GetValue().Contains(_("si"))){
                    r = getwxTextCtrl()->GetValue().find(_("si"), r);
                    aux = ((long) r ) + 2;
                    getwxTextCtrl()->SetStyle(aux - 2,aux,wxTextAttr(*wxRED));
                    getwxTextCtrl()->SetStyle(aux+1,aux+2,wxTextAttr(*wxBLACK));

        }

        if(getwxTextCtrl()->GetValue().Contains(_("selse"))){
                    r = getwxTextCtrl()->GetValue().find(_("selse"), r);
                    aux = ((long) r ) + 5;
                    getwxTextCtrl()->SetStyle(aux - 5,aux,wxTextAttr(*wxRED));
                    getwxTextCtrl()->SetStyle(aux+1,aux+2,wxTextAttr(*wxBLACK));

        }

        if(getwxTextCtrl()->GetValue().Contains(_("mientra"))){
                    r = getwxTextCtrl()->GetValue().find(_("mientra"), r);
                    aux = ((long) r ) + 7;
                    getwxTextCtrl()->SetStyle(aux - 7,aux,wxTextAttr(*wxRED));
                    getwxTextCtrl()->SetStyle(aux+1,aux+2,wxTextAttr(*wxBLACK));

        }

        if(getwxTextCtrl()->GetValue().Contains(_("para"))){
                    r = getwxTextCtrl()->GetValue().find(_("para"), r);
                    aux = ((long) r ) + 4;
                    getwxTextCtrl()->SetStyle(aux - 4,aux,wxTextAttr(*wxRED));
                    getwxTextCtrl()->SetStyle(aux+1,aux+2,wxTextAttr(*wxBLACK));

        }

        if(getwxTextCtrl()->GetValue().Contains(_("nule"))){
                    r = getwxTextCtrl()->GetValue().find(_("nule"), r);
                    aux = ((long) r ) + 4;
                    getwxTextCtrl()->SetStyle(aux - 4,aux,wxTextAttr(*wxRED));
                    getwxTextCtrl()->SetStyle(aux+1,aux+2,wxTextAttr(*wxBLACK));

        }

        if(getwxTextCtrl()->GetValue().Contains(_("nular"))){
                    r = getwxTextCtrl()->GetValue().find(_("nular"), r);
                    aux = ((long) r ) + 5;
                    getwxTextCtrl()->SetStyle(aux - 5,aux,wxTextAttr(*wxRED));
                    getwxTextCtrl()->SetStyle(aux+1,aux+2,wxTextAttr(*wxBLACK));

        }

        if(getwxTextCtrl()->GetValue().Contains(_("nule"))){
                    r = getwxTextCtrl()->GetValue().find(_("nule"), r);
                    aux = ((long) r ) + 4;
                    getwxTextCtrl()->SetStyle(aux - 4,aux,wxTextAttr(*wxRED));
                    getwxTextCtrl()->SetStyle(aux+1,aux+2,wxTextAttr(*wxBLACK));

        }


}

void Compilador_c__Frame::OnCompilar(wxCommandEvent& event)
{
    Lexer* lex = new Lexer();
    wxString msg = lex->Tokenizar(getwxTextCtrl()->GetValue().ToStdString());
    wxMessageBox(msg, _("Los tokens al parser son: "));

}
